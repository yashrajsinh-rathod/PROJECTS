import java.util.Scanner;

// Class for User Authentication
class User {
    String username;
    String password;

    User(String username, String password) {
        username = username;
        password = password;
    }

    // Method to validate login
    boolean validateLogin(String inputUsername, String inputPassword) {
        return username.equals(inputUsername) && password.equals(inputPassword);
    }
}

// Flight Class
class Flight {
    String flightNumber;
    String destination;
    int availableSeats;

    Flight() {
        // Default constructor
    }

    boolean reserveSeat() {
        if (availableSeats > 0) {
            availableSeats--;
            return true;
        }
        return false;
    }

    void cancelReservation() {
        availableSeats++;
    }

    void displayFlightDetails() {
        System.out.println("Flight Number: " + flightNumber);
        System.out.println("Destination: " + destination);
        System.out.println("Available Seats: " + availableSeats);
    }
}

// Business Class
class BusinessClass extends Flight {
    double ticketPrice;

    BusinessClass(String flightNumber, String destination, int availableSeats, double ticketPrice) {
        // Initialize fields directly without calling super
        this.flightNumber = flightNumber;
        this.destination = destination;
        this.availableSeats = availableSeats;
        this.ticketPrice = ticketPrice;
    }

    @Override
    void displayFlightDetails() {
        System.out.println("Flight Number: " + flightNumber);
        System.out.println("Destination: " + destination);
        System.out.println("Available Seats: " + availableSeats);
        System.out.println("Class: Business");
        System.out.println("Ticket Price: $" + ticketPrice);
    }
}

// Economy Class
class EconomyClass extends Flight {
    double ticketPrice;

    EconomyClass(String flightNumber, String destination, int availableSeats, double ticketPrice) {
        // Initialize fields directly without calling super
        this.flightNumber = flightNumber;
        this.destination = destination;
        this.availableSeats = availableSeats;
        this.ticketPrice = ticketPrice;
    }

    @Override
    void displayFlightDetails() {
        System.out.println("Flight Number: " + flightNumber);
        System.out.println("Destination: " + destination);
        System.out.println("Available Seats: " + availableSeats);
        System.out.println("Class: Economy");
        System.out.println("Ticket Price: $" + ticketPrice);
    }
}

// Main Class
class AirlineReservationSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // User Authentication
        User user = new User("admin", "password123");
        System.out.println("Welcome to the Airline Reservation System!");
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        if (!user.validateLogin(username, password)) {
            System.out.println("Invalid credentials. Exiting system.");
            return;
        }

        System.out.println("Login successful!");

        // Flight Data
        Flight[] flights = {
            new BusinessClass("BC101", "New York", 5, 1200.0),
            new EconomyClass("EC202", "London", 10, 500.0),
            new BusinessClass("BC303", "Paris", 3, 1500.0),
            new EconomyClass("EC404", "Tokyo", 8, 600.0),
            new BusinessClass("BC505", "Sydney", 2, 1800.0)
        };

        while (true) {
            System.out.println("\nMain Menu:");
            System.out.println("1. View All Flights");
            System.out.println("2. Search Flights by Destination");
            System.out.println("3. Reserve a Seat");
            System.out.println("4. Cancel a Reservation");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    // Display all flights
                    System.out.println("Available Flights:");
                    for (Flight flight : flights) {
                        flight.displayFlightDetails();
                        System.out.println();
                    }
                    break;

                case 2:
                    // Search flights by destination
                    System.out.print("Enter destination to search: ");
                    String destination = scanner.nextLine();
                    boolean found = false;
                    for (Flight flight : flights) {
                        if (flight.destination.equalsIgnoreCase(destination)) {
                            flight.displayFlightDetails();
                            System.out.println();
                            found = true;
                        }
                    }
                    if (!found) {
                        System.out.println("No flights found to " + destination);
                    }
                    break;

                case 3:
                    // Reserve a seat
                    System.out.print("Enter flight number to reserve: ");
                    String flightNumber = scanner.nextLine();
                    boolean seatReserved = false;
                    for (Flight flight : flights) {
                        if (flight.flightNumber.equalsIgnoreCase(flightNumber)) {
                            if (flight.reserveSeat()) {
                                System.out.println("Seat reserved successfully!");
                            } else {
                                System.out.println("No available seats on this flight.");
                            }
                            seatReserved = true;
                            break;
                        }
                    }
                    if (!seatReserved) {
                        System.out.println("Invalid flight number.");
                    }
                    break;

                case 4:
                    // Cancel a reservation
                    System.out.print("Enter flight number to cancel reservation: ");
                    String cancelFlightNumber = scanner.nextLine();
                    boolean reservationCancelled = false;
                    for (Flight flight : flights) {
                        if (flight.flightNumber.equalsIgnoreCase(cancelFlightNumber)) {
                            flight.cancelReservation();
                            System.out.println("Reservation cancelled successfully!");
                            reservationCancelled = true;
                            break;
                        }
                    }
                    if (!reservationCancelled) {
                        System.out.println("Invalid flight number.");
                    }
                    break;

                case 5:
                    // Exit
                    System.out.println("Thank you for using the Airline Reservation System!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
