public class CustomQueue<T> {
    private class Node {
        T data; Node next;
        Node(T d) { data = d; }
    }
    private Node front, rear;

    public void enqueue(T data) {
        Node n = new Node(data);
        if (rear == null) { front = rear = n; return; }
        rear.next = n; rear = n;
    }

    public T dequeue() {
        if (front == null) return null;
        T val = front.data;
        front = front.next;
        if (front == null) rear = null;
        return val;
    }

    public boolean isEmpty() {
        return front == null;
    }
}
