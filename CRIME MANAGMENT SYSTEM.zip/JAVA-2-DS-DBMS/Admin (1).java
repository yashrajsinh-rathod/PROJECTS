import java.sql.*;
import java.util.Scanner;

public class Admin extends User {
    private final Scanner sc;
    private int adminUserId;            // Users.user_id of logged-in admin
    private String adminPasswordCache;  // from DB for 2-step verify

    public Admin(Connection conn, Scanner sc) {
        super(conn);
        this.sc = sc;
    }

    @Override
    public boolean login() {
        try {
            while (true) {
                System.out.println("Enter Admin username: ");
                String uname = sc.nextLine();
                System.out.println("Enter Admin password: ");
                String pass = sc.nextLine();

                PreparedStatement ps = conn.prepareStatement(
                        "SELECT user_id, password FROM Users WHERE username=? AND password=? AND role='ADMIN'"
                );
                ps.setString(1, uname);
                ps.setString(2, pass);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    adminUserId = rs.getInt("user_id");
                    adminPasswordCache = rs.getString("password");
                    System.out.println("✅ Admin login successful");
                    return true;
                } else {
                    System.out.println("❌ Invalid admin credentials");
                }
            }
        } catch (Exception e) {
            System.out.println("❌ Admin login error: " + e.getMessage());
        }
        return false;
    }

    private void verifySecondStep() throws SQLException {
        // 2-step: re-enter admin password fetched from DB (no OTP)
        System.out.print("Re-enter admin password to confirm (2-step verification): ");
        String p = sc.nextLine();
        if (p.equals(adminPasswordCache)){
            conn.commit();
            System.out.println("✅ Crime updated");
        }
        else {
            conn.rollback();
            System.out.println("❌ Invalid admin credentials");
        }
    }

    public void menu() {
        try {
            conn.setAutoCommit(false); // admin changes require manual commit
            while (true) {
                System.out.println("\n===== ADMIN MENU =====");
                System.out.println("1. View All Crimes");
                System.out.println("2. Insert Crime");
                System.out.println("3. Update Crime");
                System.out.println("4. Delete Crime (Trigger → ClosedCase)");
                System.out.println("5. Assign Case (Manual)");
                System.out.println("6. Assign Case (Auto via Procedure)");
                System.out.println("7. Register New Officer");
                System.out.println("8. Exit");
                System.out.print("Enter Your Choice : ");
                int ch = readInt();

                switch (ch) {
                    case 1:
                        viewAllCrimes();
                        break;
                    case 2:
                        insertCrime();
                        break;
                    case 3:
                        updateCrime();
                        break;
                    case 4:
                        deleteCrime();
                        break;
                    case 5:
                        assignManual();
                        break;
                    case 6:
                        assignAuto();
                        break;
                    case 7:
                        registerOfficer();
                        break;
                    case 8:
                        try { conn.commit(); } catch (Exception ignore) {}
                        conn.setAutoCommit(true);
                        return;
                    default:
                        System.out.println("Invalid choice");
                        break;
                }
            }
        } catch (Exception e) {
            System.out.println("❌ Admin menu error: " + e.getMessage());
            try { conn.rollback(); } catch (Exception ignore) {}
        }
    }

    private int readInt() {
        while (!sc.hasNextInt()) { System.out.println("Enter a valid number: "); sc.next(); }
        int v = sc.nextInt(); sc.nextLine();
        return v;
    }

    public void viewAllCrimes() throws SQLException {
        conn.setAutoCommit(true);
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT crime_id, type, location, status, assign_to, reported_by FROM Crime");
            while (rs.next()) {
                System.out.println("CrimeID: " + rs.getInt("crime_id")
                        + " | Type: " + rs.getString("type")
                        + " | Location: " + rs.getString("location")
                        + " | Status: " + rs.getString("status")
                        + " | AssignedTo: " + rs.getString("assign_to")
                        + " | ReportedBy: " + rs.getString("reported_by"));
            }
        } catch (Exception e) {
            System.out.println("❌ View error: " + e.getMessage());
        }
    }

    private void insertCrime() throws SQLException {
        conn.setAutoCommit(false);
        try {
            // Select Type via switch-case menu
            String type = "";
            while (true) {
                System.out.println("\nSelect Crime Type:");
                System.out.println("1. Theft");
                System.out.println("2. Assault");
                System.out.println("3. Fraud");
                System.out.println("4. Cybercrime");
                System.out.println("5. Other");
                System.out.print("Enter choice: ");

                if (!sc.hasNextInt()) { System.out.println("❌ Invalid choice"); sc.next(); continue; }
                int choice = sc.nextInt(); sc.nextLine(); // clear buffer

                switch (choice) {
                    case 1: type = "Theft"; break;
                    case 2: type = "Assault"; break;
                    case 3: type = "Fraud"; break;
                    case 4: type = "Cybercrime"; break;
                    case 5:
                        System.out.println("Enter custom crime type: ");
                        type = sc.nextLine().trim();
                        if (type.isEmpty()) { System.out.println("❌ Cannot be empty"); continue; }
                        break;
                    default:
                        System.out.println("❌ Invalid option");
                        continue;
                }
                if (!type.isEmpty()) break;
            }

            String loc;
            while (true) {
                System.out.println("Enter Location (not empty): ");
                loc = sc.nextLine().trim();
                if (!loc.isEmpty()) break;
                System.out.println("❌ Location required");
            }

            String desc;
            while (true) {
                System.out.println("Enter Description (not empty): ");
                desc = sc.nextLine().trim();
                if (!desc.isEmpty()) break;
                System.out.println("❌ Description required");
            }

            String proof;
            while (true) {
                System.out.println("Enter Proof (not empty): ");
                proof = sc.nextLine().trim();
                if (!proof.isEmpty()) break;
                System.out.println("❌ Proof required");
            }

            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO Crime(type, location, status, description, proof, assign_to, reported_by) VALUES(?,?,?,?,?,NULL,NULL)",
                    Statement.RETURN_GENERATED_KEYS
            );
            ps.setString(1, type);
            ps.setString(2, loc);
            ps.setString(3, "Pending");
            ps.setString(4, desc);
            ps.setString(5, proof);
            ps.executeUpdate();
            verifySecondStep();
        } catch (Exception e) {
            System.out.println("❌ Register crime error: " + e.getMessage());
        }
    }

    private void updateCrime() throws SQLException {
        conn.setAutoCommit(false);
        try {
            System.out.println("Enter Crime ID to update: ");
            int cid = readInt();

            // Fetch current values
            PreparedStatement get = conn.prepareStatement(
                    "SELECT type, location, status, description, proof FROM Crime WHERE crime_id=?"
            );
            get.setInt(1, cid);
            ResultSet rs = get.executeQuery();
            if (!rs.next()) {
                System.out.println("⚠ Crime not found");
                return;
            }

            String oldType = rs.getString("type");
            String oldLoc = rs.getString("location");
            String oldStatus = rs.getString("status");
            String oldDesc = rs.getString("description");
            String oldProof = rs.getString("proof");

            // Prompt new values
            System.out.println("Current Type: " + oldType + " | New Type (leave blank to keep): ");
            String type = sc.nextLine().trim();
            if (type.isEmpty()) type = oldType;

            System.out.println("Current Location: " + oldLoc + " | New Location (leave blank to keep): ");
            String loc = sc.nextLine().trim();
            if (loc.isEmpty()) loc = oldLoc;

            String desc;
            while (true) {
                System.out.println("Current Description: " + oldDesc + " | New Description (leave blank to keep): ");
                desc = sc.nextLine().trim();
                if (!desc.isEmpty()) break;   // new value given
                if (oldDesc != null && !oldDesc.trim().isEmpty()) {
                    desc = oldDesc;           // keep old
                    break;
                }
                System.out.println("❌ Description cannot be empty.");
            }

            System.out.println("Current Proof: " + oldProof + " | New Proof (leave blank to keep): ");
            String proof = sc.nextLine().trim();
            if (proof.isEmpty()) proof = oldProof;

            // Execute full update
            PreparedStatement ps = conn.prepareStatement(
                    "UPDATE Crime SET type=?, location=?, description=?, proof=? WHERE crime_id=?"
            );
            ps.setString(1, type);
            ps.setString(2, loc);
            ps.setString(3, desc);
            ps.setString(4, proof);
            ps.setInt(5, cid);

            int rows = ps.executeUpdate();
            if (rows > 0) {
                verifySecondStep();
            } else {
                System.out.println("⚠ Crime not found");
            }
        } catch (Exception e) {
            System.out.println("❌ Update error: " + e.getMessage());
            try { conn.rollback(); } catch (Exception ignore) {}
        }
    }

    private void deleteCrime() throws SQLException {
        conn.setAutoCommit(false);
        try {
            System.out.println("Enter Crime ID to delete (will move to ClosedCase via trigger): ");
            int cid = readInt();
            PreparedStatement ps = conn.prepareStatement("DELETE FROM Crime WHERE crime_id=?");
            ps.setInt(1, cid);
            int rows = ps.executeUpdate();
            if (rows > 0) {
                verifySecondStep();
            } else {
                System.out.println("⚠ Crime not found");
            }
        } catch (Exception e) {
            System.out.println("❌ Delete error: " + e.getMessage());
            try { conn.rollback(); } catch (Exception ignore) {}
        }
    }

    private void assignManual() throws SQLException {
        conn.setAutoCommit(false);
        try {
            System.out.println("Enter Crime ID: ");
            int cid = readInt();
            System.out.println("Enter Officer (Users.user_id) to assign: ");
            int pid = readInt();

            // Check officer role and capacity < 2
            PreparedStatement chkRole = conn.prepareStatement(
                    "SELECT role FROM Users WHERE user_id=?"
            );
            chkRole.setInt(1, pid);
            ResultSet rr = chkRole.executeQuery();
            if (!rr.next() || !"POLICE".equals(rr.getString("role"))) {
                System.out.println("❌ Not a valid police user_id");
                return;
            }

            PreparedStatement cnt = conn.prepareStatement(
                    "SELECT COUNT(*) AS cnt FROM Crime WHERE assign_to=?"
            );
            cnt.setInt(1, pid);
            ResultSet cr = cnt.executeQuery();
            int current = 0;
            if (cr.next()) current = cr.getInt("cnt");
            if (current >= 2) {
                System.out.println("❌ Officer already has 2 cases");
                return;
            }

            // Ensure not already assigned
            PreparedStatement chk = conn.prepareStatement(
                    "SELECT assign_to FROM Crime WHERE crime_id=?"
            );
            chk.setInt(1, cid);
            ResultSet r = chk.executeQuery();
            if (!r.next()) {
                System.out.println("❌ Crime not found");
                return;
            }
            Integer to = (Integer) r.getObject("assign_to");
            if (to != null) {
                System.out.println("❌ Crime already assigned");
                return;
            }

            PreparedStatement upd = conn.prepareStatement(
                    "UPDATE Crime SET assign_to=? WHERE crime_id=?"
            );
            upd.setInt(1, pid);
            upd.setInt(2, cid);
            upd.executeUpdate();
            verifySecondStep();
        } catch (Exception e) {
            System.out.println("❌ Manual assign error: " + e.getMessage());
            try { conn.rollback(); } catch (Exception ignore) {}
        }
    }

    private void assignAuto() throws SQLException {
        conn.setAutoCommit(true);
        try {
            System.out.println("Enter Crime ID: ");
            int cid = readInt();
            CallableStatement cs = conn.prepareCall("{CALL assign_case_auto(?)}");
            cs.setInt(1, cid);
            cs.execute();
            System.out.println("✅ Auto assigned successfully");
        } catch (SQLException e) {
            System.out.println("❌ Auto assign failed: " + e.getMessage());
            try { conn.rollback(); } catch (Exception ignore) {}
        }
    }

    private void registerOfficer() {
        try {
            System.out.println("Enter Officer username: ");
            String u = sc.nextLine();
            System.out.println("Enter Officer password: ");
            String p = sc.nextLine();
            if (isNullOrEmpty(u) || isNullOrEmpty(p)) {
                System.out.println("❌ Username/password required");
                return;
            }
            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO Users(username, password, role) VALUES(?,?, 'POLICE')"
            );
            ps.setString(1, u);
            ps.setString(2, p);
            ps.executeUpdate();
            conn.commit();
            System.out.println("✅ Officer registered");
        } catch (Exception e) {
            System.out.println("❌ Register officer error: " + e.getMessage());
            try { conn.rollback(); } catch (Exception ignore) {}
        }
    }
}
