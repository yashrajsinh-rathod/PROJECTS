import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/crime_db";
    private static final String USER = "root";          // ← change
    private static final String PASSWORD = "";  // ← change

    public static Connection getConnection() {
        try {
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("✅ Database connected");
            return conn;
        } catch (Exception e) {
            System.out.println("❌ DB connection failed: " + e.getMessage());
            return null;
        }
    }
}
