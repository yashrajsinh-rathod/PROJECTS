import java.sql.*;
import java.util.Scanner;

public class Police extends User {
    private final Scanner sc;
    private int policeUserId; // Users.user_id for this police

    public Police(Connection conn, Scanner sc) {
        super(conn);
        this.sc = sc;
    }

    @Override
    public boolean login() {
        try {
            while (true) {
                System.out.println("Enter Police username: ");
                String uname = sc.nextLine();
                System.out.println("Enter Police password: ");
                String pass = sc.nextLine();

                PreparedStatement ps = conn.prepareStatement(
                        "SELECT user_id FROM Users WHERE username=? AND password=? AND role='POLICE'"
                );
                ps.setString(1, uname);
                ps.setString(2, pass);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    policeUserId = rs.getInt("user_id");
                    System.out.println("✅ Police login successful");
                    return true;
                } else {
                    System.out.println("❌ Invalid police credentials");
                }
            }
        } catch (Exception e) {
            System.out.println("❌ Police login error: " + e.getMessage());
        }
        return false;
    }

    private int readInt() {
        while (!sc.hasNextInt()) { System.out.println("Enter a valid number: "); sc.next(); }
        int v = sc.nextInt(); sc.nextLine(); return v;
    }

    public void menu() {
        while (true) {
            System.out.println("\n===== POLICE MENU =====");
            System.out.println("1. View All Crimes");
            System.out.println("2. Update Assigned Crime (description, proof)");
            System.out.println("3. Update Status of Assigned Crime");
            System.out.println("4. Exit");
            System.out.print("Enter Your Choice : ");
            int ch = readInt();

            switch (ch) {
                case 1:
                    viewAllCrimes();
                    break;
                case 2:
                    updateCrimeDetails();
                    break;
                case 3:
                    updateCrimeStatus();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice");
                    break;
            }
        }
    }

    private void viewAllCrimes() {
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT crime_id, type, location, status, assign_to FROM Crime");
            while (rs.next()) {
                System.out.println("CrimeID: " + rs.getInt("crime_id")
                        + " | Type: " + rs.getString("type")
                        + " | Location: " + rs.getString("location")
                        + " | Status: " + rs.getString("status")
                        + " | AssignedTo: " + rs.getString("assign_to"));
            }
        } catch (Exception e) {
            System.out.println("❌ View error: " + e.getMessage());
        }
    }

    private void updateCrimeDetails() {
        try {
            System.out.println("Enter Crime ID to update: ");
            int cid = readInt();

            // Get current values
            PreparedStatement sel = conn.prepareStatement(
                    "SELECT description, proof FROM Crime WHERE crime_id=? AND assign_to=?"
            );
            sel.setInt(1, cid);
            sel.setInt(2, policeUserId);
            ResultSet rs = sel.executeQuery();
            if (!rs.next()) {
                System.out.println("❌ Not your assigned case or not found");
                return;
            }
            String oldDesc = rs.getString("description");
            String oldProof = rs.getString("proof");

            System.out.println("New Description (leave blank to keep old): ");
            String desc = sc.nextLine().trim();
            if (desc.isEmpty()) desc = oldDesc;

            System.out.println("New Proof (leave blank to keep old): ");
            String proof = sc.nextLine().trim();
            if (proof.isEmpty()) proof = oldProof;

            PreparedStatement ps = conn.prepareStatement(
                    "UPDATE Crime SET description=?, proof=? WHERE crime_id=? AND assign_to=?"
            );
            ps.setString(1, desc);
            ps.setString(2, proof);
            ps.setInt(3, cid);
            ps.setInt(4, policeUserId);
            int rows = ps.executeUpdate();
            if (rows > 0) System.out.println("✅ Crime updated");
            else System.out.println("❌ Update failed");
        } catch (Exception e) {
            System.out.println("❌ Update error: " + e.getMessage());
        }
    }

    private void updateCrimeStatus() {
        try {
            System.out.println("Enter Crime ID: ");
            int cid = readInt();

            String status;
            while (true) {
                System.out.println("Enter New Status (Pending / In Progress / Solved): ");
                status = sc.nextLine().trim();
                if (status.equalsIgnoreCase("Pending") ||
                        status.equalsIgnoreCase("In Progress") ||
                        status.equalsIgnoreCase("Solved")) {
                    break;
                }
                System.out.println("❌ Invalid status. Choose only Pending, In Progress, or Solved.");
            }

            PreparedStatement ps = conn.prepareStatement(
                    "UPDATE Crime SET status=? WHERE crime_id=? AND assign_to=?"
            );
            ps.setString(1, status);
            ps.setInt(2, cid);
            ps.setInt(3, policeUserId);
            int rows = ps.executeUpdate();
            if (rows > 0) System.out.println("✅ Status updated");
            else System.out.println("❌ Not your assigned case or not found");
        } catch (Exception e) {
            System.out.println("❌ Status update error: " + e.getMessage());
        }
    }
}
