class CustomCrimeLinkedList {
    Node head;

    static class Node {
        int crimeId;
        String Type;
        String Location;
        String Status;
        Node next;

        public Node(int crimeId, String type, String location, String status) {
            this.crimeId = crimeId;
            Type = type;
            Location = location;
            Status = status;
        }
    }

    // Add new crime
    public void addCrime(int id, String type,String location,String status) {
        Node newNode = new Node(id, type ,location,status );
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) temp = temp.next;
            temp.next = newNode;
        }
    }

    // Display all crimes
    public void displayCrimes() {
        if (head==null)
        {
            System.out.println("Linked List is Empty");
        }
        else {
            Node temp = head;
            while (temp != null) {
                System.out.println("CrimeID: " + temp.crimeId + " | Type: " + temp.Type
                        + " | Location: " + temp.Location
                        + " | Status: " + temp.Status);
                temp = temp.next;
            }
        }
    }

    // Count crimes
    public int countCrimes() {
        int count = 0;
        Node temp = head;
        while (temp != null) {
            count++;
            temp = temp.next;
        }
        return count;
    }

    // Search by crime ID
    public void searchCrime(int id) {
        Node temp = head;
        while (temp != null) {
            if (temp.crimeId == id){
                break;
            }
            temp = temp.next;
        }
        if (temp.next==null&&temp.crimeId!=id){
            System.out.println("Case Not Found");
        }
        else {
            System.out.println("CrimeID: " + temp.crimeId + " | Type: " + temp.Type
                    + " | Location: " + temp.Location
                    + " | Status: " + temp.Status);
        }
    }

    public void Empty(){
        this.head=null;
    }
}