import java.sql.Connection;

public abstract class User {
    protected Connection conn;

    public User(Connection conn) {
        this.conn = conn;
    }

    public abstract boolean login();

    public abstract void menu();

    protected boolean isNullOrEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }
}
