import java.sql.*;
import java.util.Scanner;

public class CrimeManagementSystem {
    public static void main(String[] args) {
        Connection conn = DatabaseConnection.getConnection();
        if (conn == null) return;
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== MAIN MENU =====");
            System.out.println("1. Admin Login");
            System.out.println("2. Police Login");
            System.out.println("3. Citizen Login");
            System.out.println("4. Citizen Register");
            System.out.println("5. View Case Reports");
            System.out.println("6. Exit");
            System.out.print("Enter Your Choice : ");
            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1: {
                    Admin admin = new Admin(conn, sc);
                    if (admin.login()) admin.menu();
                    break;
                }
                case 2: {
                    Police police = new Police(conn, sc);
                    if (police.login()) police.menu();
                    break;
                }
                case 3: {
                    Citizen citizen = new Citizen(conn, sc);
                    if (citizen.login()) citizen.menu();
                    break;
                }
                case 4: {
                    Citizen c = new Citizen(conn, sc);
                    c.register();
                    break;
                }
                case 5:
                    viewReports(conn, sc);
                    break;
                case 6:
                    System.out.println("Thanks For Visit");
                    System.out.println("System Closed");
                    try { conn.close(); } catch (Exception ignore) {}
                    return;
                default:
                    System.out.println("Invalid choice");
                    break;
            }
        }
    }

    private static void viewReports(Connection conn, Scanner sc) {
        while (true) {
            System.out.println("\n===== REPORTS =====");
            System.out.println("1. All Cases");
            System.out.println("2. Total Cases by Status");
            System.out.println("3. Total Crimes by Location");
            System.out.println("4. Back");
            System.out.print("Enter Your Choice : ");
            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1:
                    try {
                        Statement st = conn.createStatement();
                        ResultSet rs = st.executeQuery("SELECT crime_id, type, location, status FROM Crime");
                        while (rs.next()) {
                            System.out.println("CrimeID: " + rs.getInt("crime_id")
                                    + " | Type: " + rs.getString("type")
                                    + " | Location: " + rs.getString("location")
                                    + " | Status: " + rs.getString("status"));
                        }
                    } catch (Exception e) {
                        System.out.println("❌ Error: " + e.getMessage());
                    }
                    break;
                case 2:
                    try {
                        Statement st = conn.createStatement();
                        ResultSet rs = st.executeQuery("SELECT status, COUNT(*) AS total FROM Crime GROUP BY status");
                        while (rs.next()) {
                            System.out.println("Status: " + rs.getString("status")
                                    + " | Total: " + rs.getInt("total"));
                        }
                    } catch (Exception e) {
                        System.out.println("❌ Error: " + e.getMessage());
                    }
                    break;
                case 3:
                    try {
                        Statement st = conn.createStatement();
                        ResultSet rs = st.executeQuery("SELECT location, COUNT(*) AS total FROM Crime GROUP BY location");
                        while (rs.next()) {
                            System.out.println("Location: " + rs.getString("location")
                                    + " | Total: " + rs.getInt("total"));
                        }
                    } catch (Exception e) {
                        System.out.println("❌ Error: " + e.getMessage());
                    }
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice");
                    break;
            }
        }
    }
}
