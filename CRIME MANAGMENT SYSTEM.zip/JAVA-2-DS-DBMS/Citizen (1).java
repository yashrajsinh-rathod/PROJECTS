import java.sql.*;
import java.util.Scanner;

public class Citizen extends User {
    private final Scanner sc;
    private int citizenId; // logged-in citizen
    // DS usage
    private final CustomCrimeLinkedList myCrimes = new CustomCrimeLinkedList();
    private final CustomQueue<Integer> updateQueue = new CustomQueue<>();

    public Citizen(Connection conn, Scanner sc) {
        super(conn);
        this.sc = sc;
    }

    @Override
    public boolean login() {
        try {
            System.out.println("Enter Citizen ID: ");
            int id = sc.nextInt();
            sc.nextLine();
            System.out.println("Enter Password: ");
            String pass = sc.nextLine();

            PreparedStatement ps = conn.prepareStatement(
                    "SELECT citizen_id FROM Citizen WHERE citizen_id=? AND password=?"
            );
            ps.setInt(1, id);
            ps.setString(2, pass);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                citizenId = id;
                System.out.println("✅ Citizen login successful");
                return true;
            } else {
                System.out.println("❌ Invalid citizen credentials");
            }
        } catch (Exception e) {
            System.out.println("❌ Citizen login error: " + e.getMessage());
        }
        return false;
    }

    public void register() {
        try {
            String name;
            while (true) {
                System.out.println("Enter Name (not empty): ");
                name = sc.nextLine().trim();
                if (!name.isEmpty()) break;
                System.out.println("❌ Name cannot be empty.");
            }

            int age;
            while (true) {
                System.out.println("Enter Age (>0): ");
                if (!sc.hasNextInt()) { System.out.println("❌ Invalid age"); sc.next(); continue; }
                age = sc.nextInt(); sc.nextLine();
                if (age > 0&& age < 100) break; else System.out.println("❌ Age must be Between 0 and 100");
            }

            String phone;
            while (true) {
                System.out.println("Enter Phone (10 digits): ");
                phone = sc.nextLine().trim();
                if (phone.matches("\\d{10}")) break;
                System.out.println("❌ Invalid phone");
            }

            String pwd;
            while (true) {
                System.out.println("Enter Password (>=6 chars): ");
                pwd = sc.nextLine();
                if (pwd.length() >= 6) break;
                System.out.println("❌ Too short");
            }

            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO Citizen(name, age, phone, password) VALUES(?,?,?,?)",
                    Statement.RETURN_GENERATED_KEYS
            );
            ps.setString(1, name);
            ps.setInt(2, age);
            ps.setString(3, phone);
            ps.setString(4, pwd);
            ps.executeUpdate();

            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) {
                int id = keys.getInt(1);
                System.out.println("✅ Citizen registered with ID: " + id);
            }
        } catch (Exception e) {
            System.out.println("❌ Register error: " + e.getMessage());
        }
    }

    public void menu() {
        while (true) {
            myCrimes.Empty();
            LoadCrime();
            System.out.println("\n===== CITIZEN MENU =====");
            System.out.println("1. Register Case");
            System.out.println("2. View My Cases");
            System.out.println("3. Update My Case (description)");
            System.out.println("4. Withdraw Case ");
            System.out.println("5. Search By Id");
            System.out.println("6. Total Cases");
            System.out.println("7. Exit");
            System.out.print("Enter Your Choice : ");
            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1:
                    registerCrime();
                    break;
                case 2:
                    viewMyCrimes();
                    break;
                case 3:
                    updateMyCrime();
                    break;
                case 4:
                    withdrawCase();
                    break;
                case 5:
                    System.out.println("Enter Crime Id : ");
                    int nid= sc.nextInt();
                    myCrimes.searchCrime(nid);
                    break;
                case 6:
                    System.out.println("Total Crime Register :"+myCrimes.countCrimes());
                    break;
                case 7:
                    return;
                default:
                    System.out.println("Invalid choice");
                    break;
            }
        }
    }

    private void registerCrime() {
        try {
            // Select Type via switch-case menu
            String type = "";
            while (true) {
                System.out.println("\nSelect Crime Type:");
                System.out.println("1. Theft");
                System.out.println("2. Assault");
                System.out.println("3. Fraud");
                System.out.println("4. Cybercrime");
                System.out.println("5. Other");
                System.out.print("Enter choice: ");

                if (!sc.hasNextInt()) { System.out.println("❌ Invalid choice"); sc.next(); continue; }
                int choice = sc.nextInt(); sc.nextLine(); // clear buffer

                switch (choice) {
                    case 1: type = "Theft"; break;
                    case 2: type = "Assault"; break;
                    case 3: type = "Fraud"; break;
                    case 4: type = "Cybercrime"; break;
                    case 5:
                        System.out.println("Enter custom crime type: ");
                        type = sc.nextLine().trim();
                        if (type.isEmpty()) { System.out.println("❌ Cannot be empty"); continue; }
                        break;
                    default:
                        System.out.println("❌ Invalid option");
                        continue;
                }
                if (!type.isEmpty()) break;
            }

            String loc;
            while (true) {
                System.out.println("Enter Location (not empty): ");
                loc = sc.nextLine().trim();
                if (!loc.isEmpty()) break;
                System.out.println("❌ Location required");
            }

            String desc;
            while (true) {
                System.out.println("Enter Description (not empty): ");
                desc = sc.nextLine().trim();
                if (!desc.isEmpty()) break;
                System.out.println("❌ Description required");
            }

            String proof;
            while (true) {
                System.out.println("Enter Proof (not empty): ");
                proof = sc.nextLine().trim();
                if (!proof.isEmpty()) break;
                System.out.println("❌ Proof required");
            }

            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO Crime(type, location, status, description, proof, assign_to, reported_by) VALUES(?,?,?,?,?,NULL,?)",
                    Statement.RETURN_GENERATED_KEYS
            );
            ps.setString(1, type);
            ps.setString(2, loc);
            ps.setString(3, "Pending");
            ps.setString(4, desc);
            ps.setString(5, proof);
            ps.setInt(6, citizenId);
            ps.executeUpdate();

            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) {
                int cid = keys.getInt(1);
                myCrimes.addCrime(cid, type, desc, "Pending");
                System.out.println("✅ Crime registered with ID " + cid);
            }
        } catch (Exception e) {
            System.out.println("❌ Register crime error: " + e.getMessage());
        }
    }

    private void viewMyCrimes() {
        try {
            myCrimes.displayCrimes();
        } catch (Exception e) {
            System.out.println("❌ View my crimes error: " + e.getMessage());
        }
    }

    private void updateMyCrime() {
        try {
            System.out.println("Enter Crime ID to update description: ");
            int cid = sc.nextInt();
            sc.nextLine();
            updateQueue.enqueue(cid);
            Integer target = updateQueue.dequeue();
            if (target == null) {
                System.out.println("Queue issue");
                return;
            }

            System.out.println("Enter new description (leave blank to keep old): ");
            String desc = sc.nextLine();

            String sql;
            PreparedStatement ps;
            if (desc.trim().isEmpty()) {
                // keep old description
                System.out.println("⚠️ Blank entered, keeping old description");
                return;
            } else {
                sql = "UPDATE Crime SET description=? WHERE crime_id=? AND reported_by=?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, desc);
                ps.setInt(2, target);
                ps.setInt(3, citizenId);
            }

            int rows = ps.executeUpdate();
            if (rows > 0) System.out.println("✅ Description updated");
            else System.out.println("❌ Not found or not your case");
        } catch (Exception e) {
            System.out.println("❌ Update my crime error: " + e.getMessage());
        }
    }

    private void withdrawCase() {
        try {
            System.out.println("Enter Crime ID to withdraw: ");
            int cid = sc.nextInt();
            sc.nextLine();
            PreparedStatement ps = conn.prepareStatement(
                    "DELETE FROM Crime WHERE crime_id=? AND reported_by=?"
            );
            ps.setInt(1, cid);
            ps.setInt(2, citizenId);
            int rows = ps.executeUpdate();
            if (rows > 0) {
                System.out.println("✅ Case withdrawn — trigger moved it to ClosedCase");
            } else {
                System.out.println("❌ Not found or not your case");
            }
        } catch (Exception e) {
            System.out.println("❌ Withdraw error: " + e.getMessage());
        }
    }

    private void LoadCrime(){
        try {
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT crime_id, type, location, status FROM Crime WHERE reported_by=?"
            );
            ps.setInt(1, citizenId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("crime_id");
                String type = rs.getString("type");
                String location = rs.getString("location");
                String status = rs.getString("status");
                myCrimes.addCrime(id, type, location, status);
            }
        } catch (Exception e) {
            System.out.println("❌ Load crime error: " + e.getMessage());
        }
    }
}
